package main

import "pipeline"

func main() {
	pipeline.FromString("hello from pipeline.FromString\n").Stdout()
	pipeline.FromFile(".").Stdout()

}
