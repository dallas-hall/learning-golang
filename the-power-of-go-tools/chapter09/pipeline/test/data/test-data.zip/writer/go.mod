module writer

go 1.25.11

require github.com/rogpeppe/go-internal v1.15.0

require (
	golang.org/x/sys v0.26.0 // indirect
	golang.org/x/tools v0.26.0 // indirect
)
